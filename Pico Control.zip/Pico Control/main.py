from neopixel import Neopixel
from utime import sleep
import sys

numpx = 64
pixels = Neopixel(numpx,0,28,'GRB')

pixels.brightness(255)

while True:
    
    data = sys.stdin.readline()
    
    pippo = data.decode("utf-8")

    if pippo.len() > 0:
        pixels.set_pixel(32,(0,255,0))
        pixels.show()

    else:
        pixels.set_pixel(32,(0,255,0))
        pixels.show()